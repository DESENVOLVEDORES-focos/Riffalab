"""Comparação de qualidade de áudio.

A pontuação (0-1000) combina bitrate, taxa de amostragem e o "peso" do codec,
para que o usuário consiga comparar fontes diferentes lado a lado.
"""
from __future__ import annotations

from typing import Iterable, List, Optional

from .models import AudioFormat

# Peso relativo do codec (eficiência perceptual)
PESO_CODEC = {
    "flac": 1.00, "alac": 1.00, "wav": 1.00, "aiff": 1.00, "ape": 1.00,
    "opus": 0.98, "aac": 0.90, "m4a": 0.90, "mp3": 0.88, "oga": 0.90,
    "ogg": 0.90, "vorbis": 0.92, "wma": 0.80, "ac3": 0.78, "unknown": 0.70,
}

CODECS_LOSSLESS = {"flac", "alac", "wav", "aiff", "ape", "wv", "dsf"}

# Ganho de eficiência por codec moderno (1 kbps de opus ~ 1.8 kbps de mp3).
# Usado só para COMPARAR fontes, não para exibir o bitrate real.
FATOR_EQUIV = {"opus": 1.80, "aac": 1.30, "m4a": 1.30, "vorbis": 1.15, "ogg": 1.10,
               "mp3": 1.00, "wma": 0.85, "ac3": 0.80}

# bitrate "efetivo" assumido quando a fonte não informa
BITRATE_TIPICO = {"mp3": 192, "aac": 192, "m4a": 192, "opus": 128, "ogg": 160,
                  "vorbis": 160, "wma": 192, "ac3": 448}


def eh_lossless(codec: str) -> bool:
    c = (codec or "").lower()
    if c in CODECS_LOSSLESS:
        return True
    # WAV/PCM em contêiner (pcm_s16le, pcm_s24le, ...) também é sem perda
    return c.startswith("pcm_") or c.startswith("pcm")


def pontuar(fmt: AudioFormat) -> float:
    """0-1000. Lossless sempre acima de qualquer formato com perda."""
    codec = (fmt.codec or "unknown").lower()
    peso = PESO_CODEC.get(codec, PESO_CODEC["unknown"])

    if fmt.lossless or eh_lossless(codec):
        base = 1000.0
    else:
        br = fmt.bitrate_kbps or BITRATE_TIPICO.get(codec, 160)
        br_equiv = br * FATOR_EQUIV.get(codec, 1.0)
        base = min(1000.0, br_equiv / 320.0 * 1000.0) * peso

    if fmt.sample_rate:
        if fmt.sample_rate >= 96000:
            base += 30
        elif fmt.sample_rate >= 48000:
            base += 15
        elif fmt.sample_rate <= 22050:
            base -= 120
    if fmt.channels == 1:
        base -= 80
    if fmt.estimado:
        base -= 25          # bitrate inferido, não medido
    return max(0.0, min(1000.0, base))


def rotulo(fmt: Optional[AudioFormat]) -> str:
    if not fmt:
        return "não verificado"
    p = pontuar(fmt)
    if fmt.lossless or eh_lossless(fmt.codec):
        return "Lossless"
    if p >= 850:
        return "Excelente"
    if p >= 650:
        return "Boa"
    if p >= 400:
        return "Média"
    return "Baixa"


def cor_rotulo(fmt: Optional[AudioFormat]) -> str:
    """Cores da paleta neon (usadas nos selos da interface)."""
    r = rotulo(fmt)
    return {"Lossless": "#22E8FF", "Excelente": "#B6FF3D", "Boa": "#FFE13D",
            "Média": "#FF9A3D", "Baixa": "#FF4D6D", "não verificado": "#A98BC8"}.get(r, "#A98BC8")


def melhor_de(formatos: Iterable[AudioFormat]) -> Optional[AudioFormat]:
    formatos = list(formatos)
    return max(formatos, key=pontuar) if formatos else None


def comparar(a: Optional[AudioFormat], b: Optional[AudioFormat]) -> str:
    """Texto curto comparando dois formatos (usado no histórico/log)."""
    if not a or not b:
        return "-"
    pa, pb = pontuar(a), pontuar(b)
    if abs(pa - pb) < 1:
        return "equivalentes"
    if pa > pb:
        return f"{a.descricao_curta()} é melhor que {b.descricao_curta()}"
    return f"{b.descricao_curta()} é melhor que {a.descricao_curta()}"


def deduplicar_formatos(formatos: List[AudioFormat]) -> List[AudioFormat]:
    vistos, saida = set(), []
    for f in sorted(formatos, key=pontuar, reverse=True):
        chave = (f.codec.lower(), f.bitrate_kbps, f.sample_rate, f.url)
        if chave in vistos:
            continue
        vistos.add(chave)
        saida.append(f)
    return saida
