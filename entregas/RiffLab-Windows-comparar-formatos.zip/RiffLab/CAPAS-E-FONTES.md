# Busca e escolha de capas

## Fontes automáticas

O RiffLab consulta **APIs de catálogos**, não páginas de resultados no navegador: MusicBrainz + Cover Art Archive, Apple/iTunes e Deezer. A disponibilidade, o catálogo, as limitações de uso e os direitos das imagens dependem de cada serviço. Algumas capas podem aparecer em mais de um serviço; imagens com bytes idênticos são agrupadas. As alternativas são apresentadas para revisão antes de baixar o áudio.

Para instalações novas, as três fontes estão marcadas em **Configurações → Fontes de capa**. Uma instalação com configuração anterior mantém suas escolhas: marque **Deezer** e salve para ativá-lo. Também é possível desmarcar todas as fontes. A opção Discogs antiga não é usada: o resultado de busca de lançamento, sozinho, não demonstrava que continha a faixa procurada.

Com título, artista ou álbum informado, a busca compara os metadados retornados pelo catálogo, rejeita diferenças relevantes e alguns tipos comuns de versão diferente (ao vivo, remix, instrumental etc.). Quando não encontra uma capa para o álbum informado, pode mostrar como reserva uma capa de outro álbum com **aviso explícito**; compare a edição antes de usar. Essas verificações não são garantia de acerto: confirme visualmente. Quando faltam dados ou a correspondência é insuficiente, pode não haver capa automática.

## Google Imagens e arquivos salvos

Na revisão de capa, inclusive quando não houver resultado automático:

1. Clique em **Pesquisar imagens no Google** para abrir a busca no navegador. O aplicativo não coleta resultados do Google automaticamente.
2. Confira a imagem e suas condições de uso no site de origem e salve-a no computador, se você tiver direito de usá-la.
3. Volte ao RiffLab e clique em **Escolher imagem salva**. Aceita JPEG ou PNG, no mínimo 300 px no menor lado, proporção de capa, até 6000 px por lado e 15 MB. Uma cópia vai para o cache de capas do aplicativo.
4. Confirme visualmente o álbum e clique em **Usar esta capa**, ou escolha **Não usar capa**. Imagens locais não têm sua identidade ou direitos verificados automaticamente.

A API Google Custom Search JSON não foi integrada: o Google informa que ela não está disponível a novos clientes e que será descontinuada em 1º de janeiro de 2027. Fonte: https://developers.google.com/custom-search/v1/overview

## Testes e limites

Os testes automatizados da busca usam respostas e arquivos simulados, inclusive erros de serviço e seleção de arquivo pela interface Qt offscreen. Em consulta separada, as APIs públicas do Deezer e do iTunes retornaram exemplos reais via ferramenta de acesso à web; isso não é teste completo do aplicativo com rede externa. Não houve teste em Windows, de abertura real do navegador, de busca de imagens no Google, YouTube externo ou QtWebEngine. As fontes e regras podem mudar, falhar ou produzir resultados incompletos.
